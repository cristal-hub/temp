# execution.py
# Tsclp_v2.2_volatile — мониторинг позиций.
# Полная замена: совместимость с API Samsung + per-order учёт SELL.
#
# ИЗМЕНЕНИЯ (v2.3.9-stage1 — B2 V6, Defect B: СТРОГАЯ проверка
# идентичности per-order cursor'а; база v2.3.8-stage1):
#   validate_recovery_identity() пропускала ПУСТЫЕ обязательные поля
#   cursor'а (cur_tid/cur_figi/cur_side проверялись только «если
#   непустые») — cursor мог существовать без обязательных
#   идентификаторов и задача всё равно проходила проверку. Разделены
#   ДВА формата:
#     * НОВЫЙ формат (явный маркер identity_version=2, ставится текущей
#       версией add_close_order()): обязательны trade_id, FIGI, side,
#       идентификатор собственной заявки (order_id == ключу close_orders —
#       связь с соответствующей close-заявкой); пустое/отсутствующее
#       обязательное поле -> конфликт cursor_missing_* (fail-closed),
#       противоречие снимку -> cursor_*_mismatch. Никакого молчаливого
#       пропуска пустых обязательных полей.
#     * LEGACY cursor (старые state.json, БЕЗ маркера версии): отдельная
#       строго описанная политика — проверяются ВСЕ реально доступные
#       (непустые) идентификаторы; противоречие — fail-closed; НЕПОЛНОТА
#       проверки НЕ считается конфликтом (обратная совместимость), но и
#       НЕ выдаётся за полную: режим проверки сохраняется в задаче
#       (cursor_validation="legacy_limited", персистентен в state.json).
#       Любой cursor без trade_id/figi/side автоматически «корректным
#       legacy» НЕ считается, автоматического повышения старой записи до
#       нового формата нет.
#   Дополнительно: существующий cursor по ВТОРОЙ сохранённой ссылке той
#   же close-заявки (клиентский UUID и биржевой ID — РАЗНЫЕ
#   идентификаторы, ни один не подменяет другой) проверяется на
#   противоречие снимку. _recovery_canonical_body исключает производные
#   метаданные (cursor_validation) из сравнения дубликатов.
#   Существующие механизмы (validate rec<->снимок, дедупликация,
#   fail-closed протокол) не ослаблены.
#
# ИЗМЕНЕНИЯ (v2.3.8-stage1 — B2 V5, Defect B: fail-closed валидация
# идентичности recovery-задач; база v2.3.7-stage1):
#   import_state() восстанавливал снимок задачи pending_csv_recoveries
#   через TrackedPosition.from_dict(), но НЕ проверял согласованность
#   внешней записи и снимка — при несовпадении rec.trade_id /
#   task_pos.trade_id задача могла обновить одну строку CSV, а завершиться
#   по состоянию другой. Введена validate_recovery_identity() (rec<->снимок:
#   trade_id, FIGI, своя close-заявка, привязка per-order cursor'а
#   trade_id/figi/side) — применяется при импорте каждой задачи и перед
#   каждым recovery-циклом. Противоречивая задача НЕ опрашивается, НЕ
#   меняет CSV, НЕ удаляется как завершённая — остаётся с персистентным
#   маркером "conflict". Дубликаты trade_id: идентичные записи дедуплици
#   руются детерминированно (первая), конфликтующие (разные снимки или
#   разные close-ID) — ОБЕ блокируются без произвольного выбора.
#   Существующие mechanisms (archive_pending_csv_recovery, дедуп по
#   trade_id, fail-closed recovery) не ослаблены.
#
# ИЗМЕНЕНИЯ (v2.3.3-stage1 — дефект «повторное открытие позиции при
# активной частичной SELL»):
#   Сценарий дефекта: SELL 10 лот. -> PARTIALLYFILL (исполнено 3) ->
#   apply_close_execution уменьшил локальное количество до 7 и перевёл
#   позицию в UNCERTAIN -> process_closing получил достоверный снимок
#   брокера с остатком 7 лотов -> resolve_uncertain() видел совпадение
#   broker.lots == pos.quantity и переводил позицию в OPEN, хотя
#   собственная SELL-заявка ещё не завершена (close_order_id активен).
#   SL/TP снова включались и могли отправить ПОВТОРНУЮ SELL по позиции
#   с незавершённой заявкой — перепродажа.
#   Главный принцип исправления: совпадение локального остатка с
#   брокерским количеством НЕ является основанием переводить позицию
#   в OPEN, пока терминальность собственной SELL-заявки не подтверждена.
#   Инвариант: close_order_id сбрасывается ТОЛЬКО при обработке
#   терминального отчёта (apply_close_execution / resolve_closing),
#   поэтому его наличие == «терминальность не подтверждена».
#     - resolve_uncertain(): совпадение количества при активном
#       close_order_id больше НЕ переводит позицию в OPEN — позиция
#       остаётся UNCERTAIN (SL/TP не действуют, повторная SELL
#       невозможна, новые BUY по FIGI заблокированы).
#     - apply_close_execution(): терминальный статус (FILL/CANCELLED/
#       REJECTED/EXPIRED) с ОСТАТКОМ (quantity > 0) больше НЕ переводит
#       позицию в OPEN немедленно: подтверждённые лоты учтены per-order
#       cursor'ом, завершённая заявка очищается, но остаток разрешается
#       в OPEN только после подтверждения брокерским снимком
#       (resolve_uncertain). Полное исполнение (quantity == 0) по-прежнему
#       закрывает учёт немедленно (CLOSED).
#     - apply_close_execution(): защита от противоречивых повторных
#       отчётов — рост cumulative после учтённого терминального статуса
#       отклоняется (fail-closed: UNCERTAIN, количество не меняется);
#       идемпотентный повтор терминального отчёта игнорируется целиком
#       (ни количества, ни состояния, ни дубля CSV).
#     - resolve_closing(): отказ/отмена БЕЗ исполнения (REJECTED/CANCELLED
#       при lots_executed == 0) больше НЕ возвращает позицию в OPEN
#       немедленно — очистка завершённой заявки + UNCERTAIN; возврат
#       в OPEN — только через подтверждение брокерским снимком.
#       Ветви состояний не выполняются при противоречивом отчёте
#       (apply_close_execution вернул False) — ссылка на заявку
#       сохраняется для повторного опроса.
#   Штатные сценарии сохранены: FILL закрывает учёт по фактическим
#   исполнениям и per-order cursor; CANCELLED с частичным исполнением
#   разрешает остаток как OPEN после сверки с брокером; REJECTED без
#   исполнения возвращает позицию в OPEN при подтверждённом совпадении
#   количества; неизвестный статус/ошибка запроса/None — fail-closed.
#   Торговая логика (SL/TP, входы, риск-модель) не менялась;
#   OrderLedger, P0-5, per-order cursor и fail-closed не ослаблены.
#
# ИЗМЕНЕНИЯ (v2.3.2-stage1 — аудит v2.3.1, Дефект 2 «обход двойного
# подтверждения через UNCERTAIN»):
#   - resolve_uncertain(): ветка «позиция отсутствует у брокера» БОЛЬШЕ НЕ
#     закрывает учёт по одному достоверному снимку (прежнее поведение
#     v2.3.1: мгновенный CLOSED с EXTERNAL_CLOSE — обход механизма В3).
#     Позиция ОСТАЁТСЯ в UNCERTAIN; внешнее закрытие возможно только через
#     единый механизм В3 (main.py::_try_resolve_absent_position — два
#     достоверных снимка с интервалом >= RECONCILE_CONFIRM_MIN_AGE_SECONDS),
#     закрытие собственной SELL-заявкой — только по её терминальному
#     отчёту (resolve_closing/apply_close_execution, В2). Повторная
#     отправка SELL невозможна (SL/TP действуют только на OPEN), новые BUY
#     по FIGI заблокированы. P0-5, OrderLedger, per-order cursor и
#     fail-closed не ослаблены.
#
# ИЗМЕНЕНИЯ (v2.3.1-stage1 — аудит ТЗ v2.3, пункты 4/5):
#   - TrackedPosition.exit_price_confirmed: True ТОЛЬКО когда цена выхода
#     взята из реального исполненного close-ордера этой позиции
#     (apply_close_execution при avg_exec_price>0). Служит запретом
#     фиктивного P&L в process_closing: если цена исполнения неизвестна
#     (позиция исчезла у брокера в UNCERTAIN, отчёт ордера без цены),
#     CSV-строка пишется БЕЗ P&L (поля пустые, error_note=PRICE_UNKNOWN),
#     cumulative не искажается. Поле сериализуется в state.json; старый
#     state.json восстанавливается с False (from_dict setdefault).
#   - resolve_uncertain(): ветка «позиция отсутствует у брокера» ставила
#     close_reason=EXTERNAL_CLOSE и закрывала учёт по одному снимку —
#     поведение отменено в v2.3.2-stage1 (см. шапку выше).
#   Торговая логика (SL/TP, закрытия, промоция) не менялась.
#
# ИЗМЕНЕНИЯ (исправление потери первичной регистрации BUY — guard
# register_executed_buy):
#   - ExecutionMonitor хранит компактный реестр closed_entry_order_ids —
#     entry_order_id закрытых BUY-позиций. Обоснование: monitor.positions
#     держит только одну запись на FIGI; register()/register_recovery()
#     перезаписывают CLOSED-запись новой позицией по тому же FIGI, и после
#     перезапуска невозможно было отличить «старую закрытую сделку» от
#     «новой незарегистрированной позиции». Без этого признака ослабление
#     guard первичной регистрации (ledger FILL больше не считается
#     доказательством применения лотов) открывало бы «воскрешение»
#     закрытой сделки по позднему residual-отчёту. Реестр:
#     - пополняется при перезаписи CLOSED-записи (register/register_recovery);
#     - пополняется при экспорте state (все текущие CLOSED-записи);
#     - сериализуется в state.json (export_state/import_state),
#       обратная совместимость: ключ отсутствует в старом state.json —
#       восстанавливается пустой список;
#     - НЕ ограничен по размеру (дополнительный этап): прежний FIFO-лимит
#       200 записей вытеснял признаки СТАРЫХ закрытых сделок — после 200
#       закрытий поздний residual-отчёт вытесненной заявки больше не
#       блокировался guard'ом register_executed_buy («воскрешение»
#       закрытой позиции). Каждая запись — только короткий order_id,
#       размер архива пренебрежим: безопасность важнее экономии байт.
#   Торговая логика (SL/TP, закрытия, промоция) не менялась.
#
# ИЗМЕНЕНИЯ (этап BUY REGISTRATION FIX 3 — защита на уровне execution.py):
#   apply_late_entry_lots() и record_recovery_entry_lots() отклоняют
#   исполнение с ПУСТЫМ/ОТСУТСТВУЮЩИМ order_id (None, "", только пробелы):
#   немедленный return False БЕЗ каких-либо изменений позиции (quantity,
#   entry_price, entry_applied_lots, entry_order_id не трогаются).
#   Обоснование: отсутствие достоверного идентификатора — НЕОПРЕДЕЛЁННОСТЬ,
#   а не разрешение применить исполнение. Раньше проверка принадлежности
#   (`if order_id and pos.entry_order_id and order_id != pos.entry_order_id`)
#   при пустом order_id пропускалась, и дельта применялась к существующей
#   позиции без какого-либо подтверждения, что исполнение относится именно
#   к этой позиции. Теперь:
#   - пустой/missing order_id — отклонение (лог + return False);
#   - чужой (несовпадающий с entry_order_id) order_id — отклонение
#     (как и прежде);
#   - собственный корректный order_id — штатное применение дельты
#     (как и прежде).
#   Основная защита — в вызывающем коде main.py (register_executed_buy:
#   guard BUY_EXEC_NO_ORDER_ID, uncertain_state, диагностика); эти проверки
#   — защита в глубину на уровне самого модуля: даже при обходе вызывающего
#   кода метод не применит лоты без идентификатора. Совместимость: все
#   текущие вызовы (main.py: register_executed_buy OPEN/RECOVERY-ветки,
#   promote_recovery_positions) передают непустой order_id, проверенный
#   вызывающим кодом; поведение остальных методов не менялось.
#
# ИЗМЕНЕНИЯ (v2.3.0-stage1 — телеметрия MAE/MFE и безубыток/трейлинг, С1):
#   TrackedPosition дополнен полями (в КОНЕЦ dataclass — порядок прежних
#   полей не менялся; обратная совместимость со старым state.json через
#   from_dict/setdefault):
#   - initial_sl_price / initial_tp_price — SL/TP на момент входа (плановый
#     риск R); инициализация ровно в двух точках: register() и
#     promote_recovery();
#   - mae_price / mfe_price — худшая/лучшая цена с момента входа: ТОЛЬКО
#     по high/low 5-минутных свечей (update_extremes), НЕ по точечным
#     ценам опроса — поллинг 30 с пропускает внутрибарные экстремумы;
#   - breakeven_moved — флаг перевода в безубыток.
#   Механика ВЫКЛЮЧЕНА по умолчанию (config.BE_TRAIL_ENABLED=False):
#   _update_sl() — триггер безубытка по r_peak от ДОСТИГНУТОГО максимума
#   (mfe_price, не текущей цены): SL -> entry ± буфер (2*комиссия +
#   проскальзывание); затем трейлинг SL = mfe ∓ TRAIL_ATR_MULTIPLIER*ATR,
#   только в сторону ужесточения и не хуже уровня безубытка. check_all()
#   принимает extremes/atrs (необязательные — старый вызов с одной ценой
#   работает как прежде) и классифицирует причину SL-выхода: SL / BE / TRAIL.
import json
import logging
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Dict, List, Optional

import config


class PositionState(str, Enum):
    OPEN = "OPEN"
    CLOSING = "CLOSING"
    CLOSED = "CLOSED"
    UNCERTAIN = "UNCERTAIN"
    RECOVERY = "RECOVERY"


ACTIVE_STATES = (
    PositionState.OPEN, PositionState.CLOSING,
    PositionState.UNCERTAIN, PositionState.RECOVERY,
)

# v2.3.3-stage1: терминальные статусы SELL-заявки закрытия. Единый набор
# с веткой terminal в apply_close_execution; числовые коды — для
# устойчивости к сырому значению execution_report_status.
_TERMINAL_SELL_STATUSES = {"FILL", "CANCELLED", "REJECTED", "EXPIRED", "1", "2", "3"}


def _report_value_conflict(saved, reported) -> bool:
    """v2.3.5-stage1 (B2 metadata recovery): True — ТОЛЬКО когда ОБА значения
    достоверны (не None) и различаются сверх денежного допуска.

    Отсутствующее значение (None с любой стороны) — НЕ противоречие:
    отсутствие данных в новом отчёте не равно несовпадению двух достоверных
    значений. Непарсируемое «достоверное» значение трактуется консервативно
    как конфликт (fail-closed). Семантика совпадает с
    main._confirmed_value_conflicts (проверка идентичности повторов В2):
    оба уровня защиты согласованно распознают противоречие отчёта."""
    if saved is None or reported is None:
        return False
    try:
        fs, fr = float(saved), float(reported)
    except (TypeError, ValueError):
        return True
    return abs(fs - fr) > 1e-9


@dataclass
class TrackedPosition:
    figi: str
    ticker: str
    direction: str
    entry_price: float
    quantity: int
    sl_price: float
    tp_price: float
    lot_size: int = 1
    state: PositionState = PositionState.OPEN
    close_reason: Optional[str] = None
    close_order_id: Optional[str] = None
    close_requested_at: Optional[str] = None
    close_price_before_order: float = 0.0
    executed_lots: int = 0
    execution_price: Optional[float] = None
    trade_id: str = ""
    signal_reason: str = ""
    signal_time: str = ""
    price_before_order: float = 0.0
    order_send_time: str = ""
    partial: bool = False
    logged: bool = False
    actual_commission: Optional[float] = None
    entry_actual_commission: Optional[float] = None
    entry_order_id: Optional[str] = None
    entry_requested_lots: int = 0
    entry_applied_lots: int = 0
    entry_snapshot_synced: bool = False
    close_requested_lots: int = 0
    close_applied_lots: int = 0
    recovery_source: Optional[str] = None
    # Новый журнал закрытий. Ключ — точный broker order_id.
    close_orders: Dict[str, dict] = field(default_factory=dict)
    # История применений сохраняется в state.json; записи не перезаписываются.
    close_applications: List[dict] = field(default_factory=list)
    # --- v2.3.0-stage1: телеметрия и безубыток/трейлинг (С1) ---
    # Поля добавлены В КОНЕЦ dataclass: порядок прежних полей не изменился.
    # Для старых state.json значения восстанавливаются в from_dict().
    # SL/TP на момент входа (плановый риск R = entry - initial_sl для BUY).
    initial_sl_price: float = 0.0
    initial_tp_price: float = 0.0
    # Экстремумы с момента входа: худшая цена (BUY: min low; SELL: max high)
    # и лучшая цена (BUY: max high; SELL: min low). 0.0 = «не инициализирован».
    mae_price: float = 0.0
    mfe_price: float = 0.0
    # Флаг перевода в безубыток (триггер — r_peak по достигнутому mfe).
    breakeven_moved: bool = False
    # v2.3.1-stage1 (ТЗ-5): True ТОЛЬКО когда цена выхода взята из реального
    # исполненного close-ордера этой позиции. Иначе CSV пишется без P&L
    # (запрет фиктивного P&L при неизвестной цене исполнения).
    exit_price_confirmed: bool = False
    # ЭТАП 5Б: КЛИЕНТСКИЙ UUID (ключ идемпотентности) активной SELL-заявки
    # закрытия. Известен ДО отправки (генерируется до сетевого вызова) и
    # сохраняется в позиции ДАЖЕ при потере ответа брокера — по нему заявка
    # находится в реестре и опрашивается по ORDER_ID_TYPE_REQUEST.
    # НЕ подменяет биржевой ID: биржевой ID хранится в close_order_id и
    # заполняется ТОЛЬКО настоящим ID из ответа брокера.
    close_order_request_id: Optional[str] = None

    def to_dict(self) -> dict:
        d = asdict(self)
        d["state"] = self.state.value
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "TrackedPosition":
        d = dict(data)
        if isinstance(d.get("state"), str):
            d["state"] = PositionState(d["state"])
        allowed = {f.name for f in cls.__dataclass_fields__.values()}
        d = {k: v for k, v in d.items() if k in allowed}
        # Старые state.json не содержат истории SELL. Не приписываем старый
        # singleton cursor новой заявке: legacy-запись создаётся только для
        # close_order_id, который реально сохранён в state.
        d.setdefault("close_orders", {})
        d.setdefault("close_applications", [])
        # v2.3.0-stage1: старые state.json не содержат телеметрии С1.
        # initial_* восстанавливаются из текущих sl/tp (лучшее доступное
        # приближение для уже открытых позиций), экстремумы стартуют с нуля
        # (начнут накапливаться по свечам), breakeven_moved — False.
        d.setdefault("initial_sl_price", d.get("sl_price") or 0.0)
        d.setdefault("initial_tp_price", d.get("tp_price") or 0.0)
        d.setdefault("mae_price", 0.0)
        d.setdefault("mfe_price", 0.0)
        d.setdefault("breakeven_moved", False)
        # v2.3.1-stage1 (ТЗ-5): старый state.json не содержит маркер
        # подтверждённой цены выхода — консервативно False (P&L такой
        # позиции при закрытии не рассчитывается, ошибку не делаем).
        d.setdefault("exit_price_confirmed", False)
        d.setdefault("close_order_request_id", None)
        # ЭТАП 5Б — ОБЯЗАТЕЛЬНАЯ МИГРАЦИЯ state.json (идемпотентная):
        # в старых версиях pos.close_order_id фактически содержал
        # КЛИЕНТСКИЙ UUID (ключ идемпотентности), а не биржевой ID.
        # Старый close_order_id при отсутствии нового close_order_request_id
        # переносится в close_order_request_id; close_order_id очищается
        # и заполняется ТОЛЬКО настоящим биржевым ID из ответа брокера.
        # Идемпотентность: повторная загрузка/сохранение не меняет смысл
        # идентификаторов (миграция выполняется только пока request_id пуст).
        legacy_close_oid = d.get("close_order_id")
        if legacy_close_oid and not d.get("close_order_request_id"):
            d["close_order_request_id"] = str(legacy_close_oid)
            d["close_order_id"] = None
        return cls(**d)


class ExecutionMonitor:
    # Компактный реестр entry_order_id закрытых BUY-позиций (см. шапку);
    # без лимита размера — обрезка теряла признаки старых закрытых сделок.

    # v2.3.9-stage1 (B2 V6, Defect B): версия ФОРМАТА per-order cursor'а
    # close-заявки. Начиная с этой версии add_close_order() записывает в
    # каждую НОВУЮ запись cursor'а явный маркер "identity_version" со
    # значением этой константы; записи БЕЗ маркера (старые state.json)
    # обрабатываются ОТДЕЛЬНОЙ legacy-политикой validate_recovery_identity
    # (проверка всех ДОСТУПНЫХ идентификаторов, неполнота не выдаётся за
    # полную проверку — см. cursor_validation_mode / cursor_validation).
    CURSOR_IDENTITY_VERSION = 2

    def __init__(self, client):
        self.client = client
        self.positions: Dict[str, TrackedPosition] = {}
        self.monitoring_error = False
        self.closed_entry_order_ids: List[str] = []
        # v2.3.7-stage1 (B2 V4 — PERSISTENT LATE CSV RECOVERY):
        # незавершённые задачи восстановления поздних метаданных CSV.
        # monitor.positions[figi] — НЕ единственный источник таких задач:
        # register()/register_recovery() заменяют CLOSED-запись новой
        # позицией того же FIGI, и прежний объект перестаёт попадать в
        # recovery-цикл, а поздний отчёт брокера больше не доходит до
        # его CSV-строки. Каждая задача — снимок позиции (pos.to_dict()),
        # восстанавливаемый через TrackedPosition.from_dict; персистентен
        # через export_state/import_state (state.json). Записи удаляются
        # ТОЛЬКО при завершённом восстановлении (см. main.process_closing).
        self.pending_csv_recoveries: List[dict] = []

    def _archive_closed_entry_order(self, pos: TrackedPosition) -> None:
        """Сохраняет признак закрытой сделки (entry_order_id) перед
        перезаписью CLOSED-записи новой позицией по тому же FIGI."""
        if pos is None or pos.state != PositionState.CLOSED or not pos.entry_order_id:
            return
        if pos.entry_order_id not in self.closed_entry_order_ids:
            self.closed_entry_order_ids.append(pos.entry_order_id)
            # Дополнительный этап: без обрезки архива — вытесненный признак
            # закрытой сделки терял защиту guard'а от «воскрешения».

    def archive_pending_csv_recovery(self, pos: TrackedPosition) -> None:
        """v2.3.7-stage1 (B2 V4): сохраняет незавершённую recovery-задачу
        закрытой сделки ПЕРЕД тем, как register()/register_recovery()
        заменят её новой позицией того же FIGI.

        Условие архивации (консервативное, только по данным позиции):
          CLOSED + logged (CSV-строка записана) + стабильный trade_id +
          ссылка на СВОЮ close-заявку (close_order_request_id — клиентский
          UUID / close_order_id — биржевой ID). Полнота строки CSV здесь
          сознательно НЕ проверяется (монитор не читает журнал): лишние
          задачи отбрасываются recovery-проходом после первой же проверки
          строки; незавершённые — остаются до подтверждения обоих
          фактических значений.

        Не архивируются: незалогированные закрытия (строки ещё нет —
        восстанавливать нечего) и B3-внешние закрытия без своей SELL
        (опрашивать нечего; B3 не меняется).

        Задача содержит ПОЛНЫЙ снимок позиции (pos.to_dict()): trade_id,
        ОБЕ ссылки на СВОЮ close-заявку и per-order cursor — идентичность
        отчёта и принадлежность заявки проверяются по СНИМКУ СТАРОЙ
        сделки; заявка новой позиции не опрашивается никогда.
        Дедуп по стабильному trade_id: повторная архивация той же сделки
        не создаёт вторую задачу."""
        if pos is None or pos.state != PositionState.CLOSED or not pos.logged:
            return
        trade_id = str(getattr(pos, "trade_id", "") or "")
        if not trade_id:
            # Строка со случайным trade_id надёжно не идентифицируется —
            # восстановление невозможно (fail-closed, как в recovery).
            return
        if not (pos.close_order_id or getattr(pos, "close_order_request_id", None)):
            # Нет ссылки на СВОЮ close-заявку (например, B3-внешнее
            # закрытие): опрос невозможен — задача не создаётся.
            return
        if any(rec.get("trade_id") == trade_id
               for rec in self.pending_csv_recoveries):
            return  # уже в очереди (дедуп по стабильному trade_id)
        # v2.3.9-stage1 (B2 V6, Defect B): режим проверки идентичности
        # cursor'а этой задачи — производное метаданное снимка (персистентно
        # в state.json); неполная (legacy) проверка НЕ выдаётся за полную.
        oid_ref = str(getattr(pos, "close_order_request_id", None)
                      or pos.close_order_id or "").strip()
        cursor = ((getattr(pos, "close_orders", {}) or {}).get(oid_ref)
                  if oid_ref else None)
        if not isinstance(cursor, dict):
            cursor_validation = "none"
        else:
            # v2.3.10-stage1 (B2 V7, Defect A): ТРИ состояния маркера
            # версии. LEGACY (ключа нет) -> legacy_limited; поддерживаемая
            # версия -> full; НЕКОРРЕКТНАЯ/неизвестная версия -> отдельный
            # режим "invalid_version" (НЕ legacy): fail-closed, причина
            # конфликта (cursor_invalid_identity_version) ставится
            # validate_recovery_identity() при первой проверке задачи —
            # брокер не опрашивается, CSV не изменяется, задача не
            # удаляется и не «повышается» автоматически.
            cursor_state = self._cursor_identity_state(cursor)
            if cursor_state == "new":
                cursor_validation = "full"
            elif cursor_state == "legacy":
                cursor_validation = "legacy_limited"
            else:
                cursor_validation = "invalid_version"
        self.pending_csv_recoveries.append({
            "version": 1,
            "trade_id": trade_id,
            "figi": pos.figi,
            "ticker": pos.ticker,
            "reason": "position_replaced_same_figi",
            "cursor_validation": cursor_validation,
            # Полный JSON-безопасный снимок позиции (asdict): при recovery
            # восстанавливается через TrackedPosition.from_dict — в
            # monitor.positions НЕ возвращается (учёт новой позиции
            # не затрагивается).
            "position": pos.to_dict(),
        })
        logging.warning(
            f"[execution] {pos.ticker}: закрытая сделка trade_id={trade_id} "
            f"с неполным восстановлением CSV архивирована перед заменой "
            f"позиции по тому же FIGI (задача персистентна в state.json)")

    def register(self, **kwargs) -> TrackedPosition:
        figi = kwargs.get("figi")
        if figi and self.has_active_position(figi):
            existing = self.positions[figi]
            logging.error(
                f"[execution] register: active position {figi} exists "
                f"({existing.state.value}); overwrite denied"
            )
            return existing
        self._archive_closed_entry_order(self.positions.get(figi))
        self.archive_pending_csv_recovery(self.positions.get(figi))
        pos = TrackedPosition(**kwargs)
        # v2.3.0-stage1 (С1): точка инициализации №1 — SL/TP фиксируются на
        # момент входа (плановый риск для триггера безубытка).
        if pos.initial_sl_price <= 0 and pos.sl_price > 0:
            pos.initial_sl_price = pos.sl_price
        if pos.initial_tp_price <= 0 and pos.tp_price > 0:
            pos.initial_tp_price = pos.tp_price
        if not self._valid_position(pos):
            raise ValueError("Некорректные параметры позиции")
        self.positions[pos.figi] = pos
        logging.info(
            f"[execution] {pos.state.value} {pos.ticker} qty={pos.quantity} "
            f"entry={pos.entry_price} sl={pos.sl_price} tp={pos.tp_price}"
        )
        return pos

    @staticmethod
    def _valid_position(pos):
        return (
            bool(pos.figi) and pos.quantity > 0 and pos.lot_size > 0
            and pos.direction in ("BUY", "SELL")
            and (pos.state == PositionState.RECOVERY or
                 (pos.entry_price > 0 and pos.sl_price > 0 and pos.tp_price > 0))
        )

    def register_recovery(
        self, figi, ticker, direction, quantity, lot_size, trade_id="",
        order_id=None, signal_reason="", signal_time="", price_before_order=0.0,
        order_send_time="", requested_lots=0, partial=False,
        entry_commission=None, execution_price=None, recovery_source="adopted",
    ):
        if self.has_active_position(figi):
            return self.positions[figi]
        if direction not in ("BUY", "SELL") or int(quantity) <= 0 or int(lot_size) <= 0:
            raise ValueError("Некорректная RECOVERY-позиция")
        self._archive_closed_entry_order(self.positions.get(figi))
        self.archive_pending_csv_recovery(self.positions.get(figi))
        pos = TrackedPosition(
            figi=figi, ticker=ticker, direction=direction, entry_price=0.0,
            quantity=int(quantity), sl_price=0.0, tp_price=0.0,
            lot_size=int(lot_size), state=PositionState.RECOVERY,
            executed_lots=int(quantity), trade_id=trade_id,
            signal_reason=signal_reason, signal_time=signal_time,
            price_before_order=price_before_order, order_send_time=order_send_time,
            partial=partial, entry_requested_lots=int(requested_lots or quantity),
            entry_applied_lots=int(quantity), entry_order_id=order_id,
            entry_actual_commission=entry_commission,
            execution_price=execution_price, recovery_source=recovery_source,
        )
        self.positions[figi] = pos
        logging.warning(f"[execution] RECOVERY {ticker} qty={quantity} source={recovery_source}")
        return pos

    def promote_recovery(self, pos, entry_price, sl_price, tp_price, execution_price=None):
        if pos.state != PositionState.RECOVERY:
            return False
        try:
            ep, sl, tp = float(entry_price), float(sl_price), float(tp_price)
        except (TypeError, ValueError):
            return False
        if min(ep, sl, tp) <= 0:
            return False
        pos.entry_price, pos.sl_price, pos.tp_price = ep, sl, tp
        pos.execution_price = float(execution_price) if execution_price and execution_price > 0 else ep
        pos.recovery_source = None
        # v2.3.0-stage1 (С1): точка инициализации №2 — SL/TP фиксируются на
        # момент промоции (цена входа восстановлена), экстремумы стартуют
        # от цены входа (до промоции они не отслеживались — позиция была
        # RECOVERY), флаг безубытка сброшен.
        pos.initial_sl_price = sl
        pos.initial_tp_price = tp
        pos.mae_price = ep
        pos.mfe_price = ep
        pos.breakeven_moved = False
        pos.state = PositionState.OPEN
        return True

    def sync_recovery_quantity(self, pos, broker_lots):
        if pos.state != PositionState.RECOVERY:
            return False
        try:
            lots = int(broker_lots)
        except (TypeError, ValueError):
            return False
        if lots == 0 or (lots > 0) != (pos.direction == "BUY"):
            return False
        absolute = abs(lots)
        if absolute == pos.quantity:
            pos.entry_snapshot_synced = True
            return False
        old = pos.quantity
        pos.quantity = absolute
        pos.entry_snapshot_synced = True
        if absolute > int(pos.entry_applied_lots or 0):
            pos.entry_applied_lots = absolute
            pos.executed_lots = absolute
        logging.info(f"[execution] RECOVERY {pos.ticker}: broker qty {old} -> {absolute}")
        return True

    def record_recovery_entry_lots(self, pos, executed_lots, order_id=None, already_seen_lots=None):
        if pos.state != PositionState.RECOVERY or pos.direction != "BUY":
            return False
        # Этап BUY REGISTRATION FIX 3 (защита в глубину): исполнение БЕЗ
        # достоверного order_id отклоняется целиком — отсутствие
        # идентификатора это НЕОПРЕДЕЛЁННОСТЬ, а НЕ разрешение применить
        # лоты. Позиция не изменяется (quantity/entry_price/
        # entry_applied_lots не трогаются); разрешение неопределённости —
        # вызывающим кодом (uncertain_state + диагностика) и сверкой.
        if not str(order_id or "").strip():
            logging.error(
                f"[execution] record_recovery_entry_lots: отклонено — "
                f"исполнение без достоверного order_id "
                f"(figi={pos.figi}, ticker={pos.ticker}, "
                f"entry_order_id={pos.entry_order_id or '—'}, "
                f"executed_lots={executed_lots}) — лоты НЕ применены"
            )
            return False
        if order_id and pos.entry_order_id and order_id != pos.entry_order_id:
            return False
        try:
            le = int(executed_lots)
            seen = int(already_seen_lots) if already_seen_lots is not None else 0
        except (TypeError, ValueError):
            return False
        if le < 0:
            return False
        applied = int(pos.entry_applied_lots or 0)
        baseline = max(applied, seen)
        if le < baseline:
            return False
        if le == baseline:
            if le == applied:
                return False
            pos.entry_applied_lots = pos.executed_lots = le
            return True
        if pos.entry_snapshot_synced:
            pos.entry_applied_lots = pos.executed_lots = le
            return True
        delta = le - baseline
        pos.quantity += delta
        pos.entry_applied_lots = pos.executed_lots = le
        return True

    def apply_late_entry_lots(self, pos, executed_lots, order_id=None):
        if pos.state != PositionState.OPEN or pos.direction != "BUY":
            return False
        # Этап BUY REGISTRATION FIX 3 (защита в глубину): исполнение БЕЗ
        # достоверного order_id отклоняется целиком — отсутствие
        # идентификатора это НЕОПРЕДЕЛЁННОСТЬ, а НЕ разрешение применить
        # лоты к уже открытой позиции. Позиция не изменяется (quantity/
        # entry_price/entry_applied_lots не трогаются); разрешение
        # неопределённости — вызывающим кодом (uncertain_state +
        # диагностика) и сверкой.
        if not str(order_id or "").strip():
            logging.error(
                f"[execution] apply_late_entry_lots: отклонено — "
                f"исполнение без достоверного order_id "
                f"(figi={pos.figi}, ticker={pos.ticker}, "
                f"entry_order_id={pos.entry_order_id or '—'}, "
                f"executed_lots={executed_lots}) — лоты НЕ применены"
            )
            return False
        if order_id and pos.entry_order_id and order_id != pos.entry_order_id:
            return False
        try:
            le = int(executed_lots)
        except (TypeError, ValueError):
            return False
        applied = int(pos.entry_applied_lots or 0)
        if le <= applied:
            return False
        pos.quantity += le - applied
        pos.entry_applied_lots = pos.executed_lots = le
        return True

    def add_close_order(self, pos, order_id, requested_lots, requested_at=None):
        """Регистрирует отдельную SELL-заявку до/после отправки; повторный ID идемпотентен.

        ЭТАП 5Б: вызывается close_position (через monitor_ref) ДО отправки —
        намерение SELL в журнале позиции появляется раньше сетевого вызова.
        Ключ записи — клиентский UUID заявки (совпадает с ключом реестра).
        Повторный вызов с тем же ID и тем же количеством — без изменений.

        v2.3.9-stage1 (B2 V6, Defect B): каждая НОВАЯ запись cursor'а
        получает ЯВНЫЙ маркер формата identity_version=2
        (CURSOR_IDENTITY_VERSION) — строгая проверка обязательных
        идентификаторов при recovery (validate_recovery_identity).
        Существующая запись НЕ повышается до нового формата автоматически
        (идемпотентный повтор возвращает её как есть; легаси-записи
        обрабатываются отдельной legacy-политикой)."""
        if not order_id or int(requested_lots) <= 0:
            raise ValueError("Нужны order_id и положительное requested_lots")
        oid = str(order_id)
        existing = pos.close_orders.get(oid)
        if existing:
            if int(existing["requested_lots"]) != int(requested_lots):
                pos.state = PositionState.UNCERTAIN
                raise ValueError("Один order_id получил разные requested_lots")
            return existing
        rec = {
            "order_id": oid, "trade_id": pos.trade_id, "figi": pos.figi,
            "side": "SELL" if pos.direction == "BUY" else "BUY",
            "requested_lots": int(requested_lots),
            "confirmed_executed_lots": 0, "applied_lots": 0,
            "status": "INTENT", "requested_at": requested_at,
            "avg_exec_price": None, "commission": None,
            # v2.3.9-stage1 (B2 V6, Defect B): маркер НОВОГО формата cursor'а
            # (строгая проверка обязательных идентификаторов при recovery).
            "identity_version": ExecutionMonitor.CURSOR_IDENTITY_VERSION,
        }
        pos.close_orders[oid] = rec
        return rec

    def apply_close_execution(
        self, pos, order_id, cumulative_executed_lots, status,
        execution_price=None, commission=None, requested_lots=None,
    ):
        """Применяет только новый cumulative delta именно этой SELL-заявки."""
        oid = str(order_id)
        rec = pos.close_orders.get(oid)
        if rec is None:
            if requested_lots is None:
                pos.state = PositionState.UNCERTAIN
                return False
            rec = self.add_close_order(pos, oid, requested_lots)
        try:
            cumulative = int(cumulative_executed_lots)
        except (TypeError, ValueError):
            pos.state = PositionState.UNCERTAIN
            return False
        requested = int(rec["requested_lots"])
        previous = int(rec["confirmed_executed_lots"])
        applied = int(rec["applied_lots"])
        if cumulative < previous or cumulative < applied or cumulative > requested:
            pos.state = PositionState.UNCERTAIN
            logging.error(
                f"[execution] {pos.ticker}: contradictory SELL cumulative "
                f"{cumulative}; previous={previous}, applied={applied}, requested={requested}"
            )
            return False
        delta = cumulative - applied
        if delta > pos.quantity:
            pos.state = PositionState.UNCERTAIN
            logging.error(f"[execution] {pos.ticker}: SELL delta {delta} exceeds remaining {pos.quantity}")
            return False
        # v2.3.3-stage1: терминальный статус этой заявки УЖЕ учтён — отчёт
        # «заморожен». Терминальный статус означает, что исполнение заявки
        # больше не изменится, поэтому:
        #   - рост cumulative после учтённого терминала — противоречивый
        #     поздний/дублирующий отчёт: fail-closed, применение ЗАПРЕЩЕНО
        #     (количество позиции не меняется, повторного применения нет,
        #     дубль CSV-строки исключён);
        #   - повтор ТОГО ЖЕ терминального отчёта игнорируется целиком —
        #     идемпотентность без побочных эффектов на состояние позиции
        #     (раньше повтор CANCELLED переводил разрешённую позицию
        #     обратно в OPEN, а повтор PARTIALLYFILL — сбрасывал в
        #     UNCERTAIN, оба без доказательств).
        prev_status = str(rec.get("status") or "").upper()
        if prev_status in _TERMINAL_SELL_STATUSES:
            if cumulative > previous:
                pos.state = PositionState.UNCERTAIN
                logging.error(
                    f"[execution] {pos.ticker}: cumulative {cumulative} > "
                    f"учтённого терминального {previous} ({prev_status}) — "
                    f"противоречивый отчёт по завершённой заявке {oid}, "
                    f"применение запрещено (fail-closed)"
                )
                return False
            # v2.3.5-stage1 (B2 metadata recovery): повторный терминальный
            # отчёт уже учтён per-order cursor'ом — НО он может содержать
            # НОВЫЕ подтверждённые брокером метаданные (цена исполнения,
            # фактическая комиссия), отсутствовавшие при первой обработке
            # (раньше повтор возвращал False ДО обновления rec/поля позиции,
            # и фактически предоставленные брокером цена/комиссия терялись).
            # Безопасное обогащение:
            #   - два ДОСТОВЕРНЫХ противоречивых значения — fail-closed:
            #     UNCERTAIN, лог, без повторного применения;
            #   - сохранённые значения НЕ затираются и НЕ перезаписываются;
            #   - отсутствие значения в новом отчёте — НЕ противоречие;
            #   - лоты НЕ применяются повторно: applied_lots,
            #     confirmed_executed_lots, pos.quantity, close_applications
            #     не изменяются (защита от роста cumulative выше сохранена).
            saved_price = rec.get("avg_exec_price")
            saved_commission = rec.get("commission")
            if (_report_value_conflict(saved_price, execution_price)
                    or _report_value_conflict(saved_commission, commission)):
                pos.state = PositionState.UNCERTAIN
                logging.error(
                    f"[execution] {pos.ticker}: повторный терминальный отчёт "
                    f"{oid} противоречит учтённому: price {execution_price} "
                    f"vs {saved_price}, commission {commission} vs "
                    f"{saved_commission} — применение запрещено (fail-closed)"
                )
                return False
            enriched = []
            if execution_price is not None and execution_price > 0 and saved_price is None:
                rec["avg_exec_price"] = float(execution_price)
                enriched.append("avg_exec_price")
            if commission is not None and saved_commission is None:
                rec["commission"] = float(commission)
                enriched.append("commission")
            # Синхронизация legacy-полей позиции с (обогащённым) cursor'ом.
            # Состояние позиции НЕ меняется: безопасный повтор не переводит
            # разрешённую позицию из OPEN в UNCERTAIN и обратно. Цены
            # подтверждение (exit_price_confirmed) следует инварианту ТЗ-5:
            # цена подтверждена ТОЛЬКО из отчёта реального исполненного
            # close-ордера (avg_exec_price cursor'а).
            pos.execution_price = rec.get("avg_exec_price")
            pos.exit_price_confirmed = rec.get("avg_exec_price") is not None
            pos.actual_commission = rec.get("commission")
            if enriched:
                logging.info(
                    f"[execution] {pos.ticker}: повторный терминальный отчёт "
                    f"{oid} ({prev_status}, cumulative={cumulative}) — лоты "
                    f"уже учтены (без повторного применения), восстановлены "
                    f"метаданные брокера: {', '.join(enriched)}"
                )
            else:
                logging.info(
                    f"[execution] {pos.ticker}: повторный терминальный отчёт "
                    f"{oid} ({prev_status}, cumulative={cumulative}) — "
                    f"игнорируется (уже учтён per-order cursor'ом)"
                )
            return False
        # Записываем подтверждение и применение как отдельные поля одной записи.
        rec["confirmed_executed_lots"] = cumulative
        rec["status"] = str(status)
        if execution_price is not None and execution_price > 0:
            rec["avg_exec_price"] = float(execution_price)
        if commission is not None:
            rec["commission"] = float(commission)
        if delta:
            from_applied = applied
            pos.quantity -= delta
            rec["applied_lots"] = cumulative
            pos.close_applications.append({
                "order_id": oid, "from_applied_lots": from_applied,
                "to_applied_lots": cumulative, "delta_lots": delta,
            })
        else:
            rec["applied_lots"] = applied
        # Совместимые legacy-поля отражают только текущий/последний ордер.
        # ЭТАП 5Б: совпадение проверяется с ОБЕИМИ ссылками позиции — ключ
        # журнала (oid) всегда клиентский UUID, а close_order_id после
        # разделения хранит БИРЖЕВОЙ ID (совпадёт только для legacy).
        if oid in (pos.close_order_id, getattr(pos, "close_order_request_id", None)):
            pos.close_requested_lots = requested
            pos.close_applied_lots = int(rec["applied_lots"])
        pos.executed_lots = cumulative
        pos.execution_price = rec["avg_exec_price"]
        # v2.3.1-stage1 (ТЗ-5): цена выхода подтверждена ТОЛЬКО если она
        # получена из отчёта исполненного close-ордера (avg_exec_price>0).
        pos.exit_price_confirmed = rec["avg_exec_price"] is not None
        pos.actual_commission = rec["commission"]
        terminal = str(status).upper() in _TERMINAL_SELL_STATUSES
        full = cumulative == requested
        if pos.quantity == 0:
            pos.state = PositionState.CLOSED
        elif terminal:
            # v2.3.3-stage1: терминальный отчёт учтён per-order cursor'ом,
            # завершённая заявка очищается, НО остаток позиции
            # (quantity > 0) разрешается в OPEN ТОЛЬКО после подтверждения
            # брокерским снимком (resolve_uncertain в process_closing).
            # Прежний немедленный OPEN позволял SL/TP отправить новую SELL
            # до сверки локального остатка с брокерским — риск перепродажи
            # при расхождении. UNCERTAIN безопасен: SL/TP не действуют,
            # новые BUY по FIGI заблокированы, повторная SELL не
            # отправляется. Полное исполнение (quantity == 0) закрыто выше.
            pos.state = PositionState.UNCERTAIN
            if oid in (pos.close_order_id, getattr(pos, "close_order_request_id", None)):
                # ЭТАП 5Б: очищаются ОБЕ ссылки заявки — и биржевой ID, и
                # клиентский UUID (журнал close_orders сохраняется целиком).
                pos.close_order_id = None
                pos.close_order_request_id = None
                pos.close_requested_lots = 0
                pos.close_applied_lots = 0
        elif str(status).upper() in {"PARTIALLYFILL", "5"}:
            pos.state = PositionState.UNCERTAIN
        else:
            pos.state = PositionState.CLOSING
        return True

    def get_position(self, figi):
        return self.positions.get(figi)

    def has_active_position(self, figi):
        p = self.positions.get(figi)
        return p is not None and p.state in ACTIVE_STATES

    # --- v2.3.0-stage1 (С1): безубыток/трейлинг (ВЫКЛЮЧЕНО по умолчанию) ---

    @staticmethod
    def _be_buffer(entry_price: float) -> float:
        """Буфер безубытка: компенсация двойной комиссии + проскальзывания."""
        return entry_price * (2 * config.COMMISSION_PER_SIDE + config.SLIPPAGE_PERCENT)

    @staticmethod
    def _risk_per_share(pos) -> float:
        """Плановый риск на акцию: entry - initial_sl (BUY); initial_sl - entry (SELL)."""
        if pos.direction == "BUY":
            return pos.entry_price - pos.initial_sl_price
        return pos.initial_sl_price - pos.entry_price

    def update_extremes(self, pos, high, low) -> bool:
        """Обновляет MAE/MFE по high/low 5-минутной свечи (НЕ по точечным
        ценам опроса: поллинг 30 с пропускает внутрибарные экстремумы).
        BUY:  mfe = max(high), mae = min(low). SELL: зеркально.
        Только для OPEN-позиций; значение 0.0 трактуется как «не инициализирован»."""
        if pos.state != PositionState.OPEN:
            return False
        try:
            high = float(high) if high is not None else None
            low = float(low) if low is not None else None
        except (TypeError, ValueError):
            return False
        changed = False
        if pos.direction == "BUY":
            if high and high > 0 and (pos.mfe_price <= 0 or high > pos.mfe_price):
                pos.mfe_price = high
                changed = True
            if low and low > 0 and (pos.mae_price <= 0 or low < pos.mae_price):
                pos.mae_price = low
                changed = True
        else:
            if low and low > 0 and (pos.mfe_price <= 0 or low < pos.mfe_price):
                pos.mfe_price = low
                changed = True
            if high and high > 0 and (pos.mae_price <= 0 or high > pos.mae_price):
                pos.mae_price = high
                changed = True
        return changed

    def _update_sl(self, pos, atr) -> None:
        """Триггер безубытка и трейлинг (С1).

        Триггер — по ДОСТИГНУТОМУ максимуму (r_peak от mfe_price, не от
        текущей цены): при r_peak >= BE_TRIGGER_R SL переносится на
        entry ± буфер (2*комиссия + проскальзывание). После перевода —
        трейлинг: SL = mfe ∓ TRAIL_ATR_MULTIPLIER*ATR, только в сторону
        ужесточения и не хуже уровня безубытка. SL никогда не ослабляется.
        Работает только при config.BE_TRAIL_ENABLED=True (по умолчанию
        выключено — поведение системы идентично прежнему)."""
        if not getattr(config, "BE_TRAIL_ENABLED", False):
            return
        if pos.state != PositionState.OPEN:
            return
        risk = self._risk_per_share(pos)
        if risk <= 0:
            return
        buffer = self._be_buffer(pos.entry_price)
        if pos.direction == "BUY":
            # --- триггер безубытка ---
            if not pos.breakeven_moved and pos.mfe_price > 0:
                r_peak = (pos.mfe_price - pos.entry_price) / risk
                if r_peak >= config.BE_TRIGGER_R:
                    new_sl = pos.entry_price + buffer
                    if new_sl > pos.sl_price:
                        logging.info(
                            f"[execution] {pos.ticker}: BE trigger r_peak={r_peak:.2f} "
                            f"(mfe={pos.mfe_price:.4f}) — SL {pos.sl_price:.4f} -> {new_sl:.4f}"
                        )
                        pos.sl_price = new_sl
                    pos.breakeven_moved = True
            # --- трейлинг от достигнутого максимума ---
            if pos.breakeven_moved and atr and atr > 0 and pos.mfe_price > 0:
                candidate = pos.mfe_price - config.TRAIL_ATR_MULTIPLIER * float(atr)
                if candidate > pos.sl_price and candidate > pos.entry_price + buffer:
                    logging.info(
                        f"[execution] {pos.ticker}: TRAIL — SL {pos.sl_price:.4f} -> {candidate:.4f} "
                        f"(mfe={pos.mfe_price:.4f}, atr={float(atr):.4f})"
                    )
                    pos.sl_price = candidate
        else:
            # --- зеркало для SHORT (в текущей стратегии не используются,
            # но учёт поддерживает адопцию SHORT-позиций) ---
            if not pos.breakeven_moved and pos.mfe_price > 0:
                r_peak = (pos.entry_price - pos.mfe_price) / risk
                if r_peak >= config.BE_TRIGGER_R:
                    new_sl = pos.entry_price - buffer
                    if new_sl < pos.sl_price:
                        pos.sl_price = new_sl
                    pos.breakeven_moved = True
            if pos.breakeven_moved and atr and atr > 0 and pos.mfe_price > 0:
                candidate = pos.mfe_price + config.TRAIL_ATR_MULTIPLIER * float(atr)
                if candidate < pos.sl_price and candidate < pos.entry_price - buffer:
                    pos.sl_price = candidate

    def _classify_sl_exit(self, pos) -> str:
        """Причина SL-выхода для журнала: SL (штатный стоп) / BE (безубыток)
        / TRAIL (трейлинг выше уровня безубытка)."""
        if not pos.breakeven_moved:
            return "SL"
        buffer = self._be_buffer(pos.entry_price)
        if pos.direction == "BUY":
            return "TRAIL" if pos.sl_price > pos.entry_price + buffer else "BE"
        return "TRAIL" if pos.sl_price < pos.entry_price - buffer else "BE"

    async def check_all(self, prices: Dict[str, float], extremes=None, atrs=None) -> List[TrackedPosition]:
        """Проверка SL/TP по всем OPEN-позициям.

        v2.3.0-stage1: extremes — {figi: (high, low)} последней 5-мин свечи,
        atrs — {figi: ATR}. Порядок обработки позиции: экстремумы ->
        триггер BE/трейлинг (только при BE_TRAIL_ENABLED=True) -> проверка
        SL/TP. При срабатывании стопа причина классифицируется (SL/BE/TRAIL).
        Вызов с одним аргументом (только цены) работает как прежде."""
        to_close = []
        self.monitoring_error = False
        if prices is None or not prices:
            self.monitoring_error = True
            return to_close
        for pos in list(self.positions.values()):
            if pos.state != PositionState.OPEN:
                continue
            price = prices.get(pos.figi)
            if price is None or price <= 0:
                self.monitoring_error = True
                continue
            # С1: свечные экстремумы -> триггер BE/трейлинг -> SL/TP
            if extremes:
                candle = extremes.get(pos.figi)
                if candle:
                    self.update_extremes(pos, candle[0], candle[1])
            if getattr(config, "BE_TRAIL_ENABLED", False):
                self._update_sl(pos, (atrs or {}).get(pos.figi))
            if pos.direction == "BUY":
                hit_tp = price >= pos.tp_price
                hit_sl = price <= pos.sl_price
            else:
                hit_tp = price <= pos.tp_price
                hit_sl = price >= pos.sl_price
            if hit_tp:
                reason = "TP"
            elif hit_sl:
                reason = self._classify_sl_exit(pos)
            else:
                reason = None
            if reason:
                pos.state = PositionState.CLOSING
                pos.close_reason = reason
                pos.close_price_before_order = float(price)
                to_close.append(pos)
        return to_close

    async def resolve_closing(self, pos, ledger=None):
        """Проверяет активную SELL-заявку закрытия. История предыдущих SELL сохраняется.

        ЭТАП 5Б: опрос с ЯВНЫМ типом идентификатора:
          - известен БИРЖЕВОЙ ID (close_order_id из ответа брокера) —
            запрос по ORDER_ID_TYPE_EXCHANGE;
          - известен ТОЛЬКО клиентский UUID (потерянный ответ брокера,
            миграция старого state.json) — запрос по ORDER_ID_TYPE_REQUEST
            (клиентский UUID НЕ передаётся как биржевой ID).
        Ключ журнала close_orders — клиентский UUID (совпадает с ключом
        реестра заявок). Если брокер не отвечает по обоим типам —
        состояние неизвестно: позиция остаётся UNCERTAIN (fail-closed),
        никакой имитации успешного поиска.

        ledger (опционально): реестр заявок для СИНХРОНИЗАЦИИ статуса
        SELL-записи с фактическим отчётом брокера. Без синхронизации
        запись реестра остаётся в устаревшем статусе (например
        PARTIALLYFILL) после обработки терминального отчёта заявки — и
        FIGI-level блокировка (resolve_uncertain / close_position) не
        снимется даже после достоверного терминального результата.
        Синхронизация идемпотентна: повторный отчёт с тем же
        cumulative исполнением не меняет учёт (per-order cursor).
        Логика частичного исполнения apply_close_execution НЕ меняется."""
        req_id = getattr(pos, "close_order_request_id", None)
        exch_id = pos.close_order_id
        # Ключ журнала/реестра — клиентский UUID; для legacy-позиций
        # (до миграции/в памяти) request_id может быть пуст — тогда ключ
        # прежний (close_order_id исторически содержал клиентский UUID).
        oid = str(req_id or exch_id or "")
        if not oid:
            pos.state = PositionState.UNCERTAIN
            return
        try:
            if exch_id:
                # Биржевой ID известен — запрос строго по EXCHANGE.
                state = await self.client.get_sandbox_order_state(
                    str(exch_id), order_id_type="EXCHANGE",
                )
            else:
                # Только клиентский UUID — запрос строго по REQUEST.
                state = await self.client.get_sandbox_order_state(
                    str(req_id), order_id_type="REQUEST",
                )
            if state is None:
                pos.state = PositionState.UNCERTAIN
                return
            raw = getattr(state, "execution_report_status", None)
            try:
                status_int = int(raw) if raw is not None else -1
            except (TypeError, ValueError):
                status_int = -1
            status = {1: "FILL", 2: "REJECTED", 3: "CANCELLED", 4: "NEW", 5: "PARTIALLYFILL"}.get(status_int, str(raw))
            lots = int(getattr(state, "lots_executed", 0) or 0)
            requested = int(pos.close_requested_lots or pos.quantity)
            price = self._extract_price(state, lots, pos.lot_size)
            commission = self._extract_commission(state)
            if oid not in pos.close_orders:
                # Миграция legacy-позиции: старый cursor нельзя безопасно
                # переносить на неизвестную новую заявку. Он применим только
                # к order_id, записанному в state.json.
                self.add_close_order(pos, oid, requested, pos.close_requested_at)
                legacy_applied = int(pos.close_applied_lots or 0)
                if legacy_applied:
                    # В старом формате cursor мог относиться к предыдущей SELL:
                    # доказать его принадлежность текущему order_id невозможно.
                    # Не переносим его и не списываем повторно — fail closed.
                    pos.state = PositionState.UNCERTAIN
                    logging.error(
                        f"[execution] {pos.ticker}: legacy close_applied_lots="
                        f"{legacy_applied} без per-order истории; требуется reconcile"
                    )
                    return
            applied_ok = self.apply_close_execution(
                pos, oid, lots, status, price, commission, requested
            )
            # ЭТАП 5Б (§4.3): синхронизация записи реестра с фактическим
            # отчётом брокера (статус + cumulative исполнение этой заявки).
            # Без неё незавершённая SELL-запись реестра блокирует разрешение
            # позиции ПОСЛЕ терминального отчёта (FIGI-level блокировка не
            # снимается). Повтор терминального отчёта — идемпотентен
            # (ledger сам защищает исполнение от регрессии/переполнения).
            if ledger is not None and applied_ok:
                try:
                    # reason записи СОХРАНЯЕТСЯ: он несёт атрибуцию закрытия
                    # ("close:SL" и т.п.), используемую пакетом В2 для
                    # close_reason CSV-строки. Меняются только статус/лоты/цена.
                    prev_rec = ledger.latest(oid)
                    prev_reason = str((prev_rec or {}).get("reason") or "")
                    ledger.record_status(
                        oid, str(status) if status else "UNKNOWN",
                        figi=pos.figi, ticker=pos.ticker,
                        side="SELL" if pos.direction == "BUY" else "BUY",
                        requested_lots=int(requested),
                        executed_lots=int(lots),
                        avg_exec_price=price,
                        reason=prev_reason or "статус заявки закрытия подтверждён брокером",
                        source="resolve_closing",
                    )
                except Exception as ledger_exc:
                    logging.error(
                        f"[execution] {pos.ticker}: синхронизация реестра для "
                        f"SELL {oid} не удалась: {type(ledger_exc).__name__}: {ledger_exc}"
                    )
            if status_int == 5 and pos.state != PositionState.CLOSED:
                pos.state = PositionState.UNCERTAIN
            elif (applied_ok and status_int in (2, 3) and lots == 0
                  and pos.state != PositionState.CLOSED):
                # v2.3.3-stage1: отказ/отмена БЕЗ исполнения. Заявка
                # терминальна и очищается, но возврат в OPEN — только после
                # подтверждения брокерским снимком (resolve_uncertain):
                # при отсутствии/расхождении позиции у брокера немедленный
                # OPEN позволял SL/TP отправить обречённую SELL. Ветвь не
                # выполняется при противоречивом отчёте (applied_ok=False,
                # в т.ч. замороженный терминальный повтор) — ссылка на
                # заявку сохраняется для повторного опроса.
                pos.state = PositionState.UNCERTAIN
                # ЭТАП 5Б: очищаются ОБЕ ссылки (биржевой ID и клиентский
                # UUID) — разрешение остатка только по брокерскому снимку.
                pos.close_order_id = None
                pos.close_order_request_id = None
                pos.close_requested_lots = 0
                pos.close_applied_lots = 0
            elif status_int == 1 and lots < requested and pos.state != PositionState.CLOSED:
                pos.state = PositionState.UNCERTAIN
        except Exception as exc:
            logging.error(f"[execution] resolve_closing {pos.ticker}: {type(exc).__name__}: {exc}")
            pos.state = PositionState.UNCERTAIN

    def resolve_uncertain(self, pos, broker_positions, ledger=None):
        broker = broker_positions.get(pos.figi)
        if broker is None:
            # v2.3.2-stage1 (Дефект-2: обход двойного подтверждения через
            # UNCERTAIN). РАНЬШЕ позиция здесь немедленно закрывалась по
            # ОДНОМУ достоверному снимку «позиция отсутствует» — это
            # обходило механизм В3 (два достоверных снимка с минимальным
            # интервалом) и закрывало учёт, пока исход собственной
            # SELL-заявки не подтверждён (кейс: UNCERTAIN + позиция
            # исчезла -> мгновенный CLOSED с неизвестной ценой).
            # ТЕПЕРЬ: отсутствие позиции у брокера при UNCERTAIN учёт НЕ
            # закрывает. Позиция ОСТАЁТСЯ в UNCERTAIN:
            #   - исполнение собственной close-заявки разрешится штатно:
            #     process_closing -> resolve_closing -> apply_close_execution
            #     (per-order cursor, идемпотентно) с РЕАЛЬНОЙ ценой, либо
            #     В2 в reconcile (достоверный ТЕРМИНАЛЬНЫЙ отчёт реестра);
            #   - внешнее закрытие проходит ТОЛЬКО через единый механизм В3
            #     (_try_resolve_absent_position в reconcile): первый
            #     достоверный снимок -> кандидат, закрытие — только после
            #     ВТОРОГО достоверного снимка с интервалом не меньше
            #     RECONCILE_CONFIRM_MIN_AGE_SECONDS;
            #   - get_positions()=None (недостоверный снимок) сюда не доходит:
            #     process_closing при None не вызывает resolve_uncertain и не
            #     трогает кандидатов В3 — снимок НИ подтверждает, НИ сбрасывает
            #     подозрение;
            #   - повторная отправка SELL не выполняется: SL/TP действуют
            #     только на OPEN (check_all), close_position для UNCERTAIN
            #     не вызывается;
            #   - новые BUY по FIGI заблокированы (UNCERTAIN в реестре/
            #     ACTIVE_STATES + client.uncertain_state), P0-5/OrderLedger/
            #     fail-closed не затронуты.
            pos.state = PositionState.UNCERTAIN
            return
        if getattr(broker, "direction", "UNKNOWN") == "UNKNOWN":
            pos.state = PositionState.UNCERTAIN
            return
        expected = "LONG" if pos.direction == "BUY" else "SHORT"
        if broker.direction != expected or abs(int(broker.lots)) != pos.quantity:
            pos.state = PositionState.UNCERTAIN
            return
        # v2.3.3-stage1 (дефект «повторное открытие при активной частичной
        # SELL»): совпадение количества — НЕ основание для OPEN, пока
        # собственная SELL-заявка закрытия имеет неподтверждённую
        # терминальность. close_order_id сбрасывается ТОЛЬКО обработкой
        # терминального отчёта (apply_close_execution / resolve_closing),
        # поэтому его наличие означает: заявка ещё жива (NEW/PARTIALLYFILL)
        # или её исход не подтверждён. Кейс дефекта: SELL 10, исполнено 3
        # (PARTIALLYFILL), локальный остаток 7 == broker.lots 7 — раньше
        # позиция переводилась в OPEN, SL/TP снова включались и могли
        # отправить повторную SELL по позиции с незавершённой заявкой
        # (перепродажа). Теперь позиция остаётся UNCERTAIN: SL/TP не
        # действуют, повторная SELL невозможна, новые BUY по FIGI
        # заблокированы (has_active_position). Штатное разрешение
        # сохранено: терминальный отчёт очищает close_order_id, следующий
        # достоверный снимок с совпадающим остатком возвращает позицию
        # в OPEN.
        #
        # ЭТАП 5Б (§4.3 постановки):
        #   1) проверяются ОБЕ ссылки заявки: close_order_id (биржевой ID)
        #      И close_order_request_id (клиентский UUID, сохранённый даже
        #      при ПОТЕРЯННОМ ответе брокера — совпадение количества в
        #      портфеле не доказывает, что потерянная SELL не принята);
        #   2) OPEN запрещён, если в реестре существует незавершённая
        #      SELL-запись по FIGI (INTENT/SENT/NEW/PARTIALLYFILL/UNCERTAIN
        #      и заявление с неизвестной судьбой после краха между INTENT и
        #      сохранением state.json). Совпадение количества в портфеле
        #      НЕ является доказательством того, что предыдущая SELL не
        #      принята брокером.
        # Автоматическое снятие блокировки — ТОЛЬКО после достоверного
        # ТЕРМИНАЛЬНОГО результата исходной заявки (apply_close_execution /
        # resolve_closing) либо отдельного операторского разрешения;
        # общая логика В2/В3 не меняется.
        close_side = "SELL" if pos.direction == "BUY" else "BUY"
        ledger_has_open_sell = (
            ledger is not None
            and ledger.figi_has_open_order(pos.figi, close_side)
        )
        if pos.close_order_id or getattr(pos, "close_order_request_id", None) or ledger_has_open_sell:
            block_source = ("close_order_id=" + str(pos.close_order_id)
                            if pos.close_order_id else
                            ("close_order_request_id=" + str(getattr(pos, "close_order_request_id", None))
                             if getattr(pos, "close_order_request_id", None) else
                             "незавершённая SELL-запись реестра по FIGI"))
            logging.warning(
                f"[execution] {pos.ticker}: остаток {abs(int(broker.lots))} лот. "
                f"совпадает с локальным, но исходная SELL-заявка закрытия не "
                f"разрешена ({block_source}; ledger_has_open_sell="
                f"{ledger_has_open_sell}) — терминальность не подтверждена, "
                f"повторное открытие ЗАПРЕЩЕНО, позиция остаётся UNCERTAIN"
            )
            pos.state = PositionState.UNCERTAIN
            return
        pos.quantity = abs(int(broker.lots))
        pos.state = PositionState.OPEN

    @staticmethod
    def _extract_price(state, lots_executed, lot_size):
        try:
            ep = getattr(state, "executed_order_price", None)
            if ep is None or lots_executed <= 0 or lot_size <= 0:
                return None
            total = float(ep.units) + float(ep.nano) / 1e9
            return total / (lots_executed * lot_size)
        except Exception:
            return None

    @staticmethod
    def _extract_commission(state):
        # BUY ACCOUNTING AUDIT (v1, FIX-3): commission = 0.0 — ДОСТОВЕРНОЕ
        # значение брокера («комиссия реально нулевая»), оно отличается от
        # отсутствующего значения (None). Прежнее поведение (0 -> None)
        # теряло факт нулевой комиссии и подменяло её модельной.
        try:
            ec = getattr(state, "executed_commission", None)
            if ec is None:
                return None
            value = abs(float(ec.units) + float(ec.nano) / 1e9)
            return value
        except Exception:
            return None

    def active_count(self):
        return sum(p.state in ACTIVE_STATES for p in self.positions.values())

    def export_state(self):
        # Компактный реестр закрытых входных заявок: архив перезаписанных
        # записей + все текущие CLOSED-записи (дедуп; БЕЗ лимита размера —
        # обрезка теряла признаки старых закрытых сделок, см. шапку).
        closed_ids = list(self.closed_entry_order_ids)
        for pos in self.positions.values():
            if pos.state == PositionState.CLOSED and pos.entry_order_id:
                if pos.entry_order_id not in closed_ids:
                    closed_ids.append(pos.entry_order_id)
        return {
            "positions": {figi: pos.to_dict() for figi, pos in self.positions.items()},
            "monitoring_error": self.monitoring_error,
            "closed_entry_order_ids": closed_ids,
            # v2.3.7-stage1 (B2 V4): незавершённые recovery-задачи переживают
            # перезапуск. Приватные (runtime-only) ключи записей не
            # сохраняются — в state.json попадает только устойчивый снимок.
            "pending_csv_recoveries": [
                {k: v for k, v in rec.items() if not str(k).startswith("_")}
                for rec in self.pending_csv_recoveries
            ],
        }

    # =================================================================
    # v2.3.8-stage1 (B2 V5, Defect B): fail-closed ВАЛИДАЦИЯ ИДЕНТИЧНОСТИ
    # recovery-задач (pending_csv_recoveries).
    #
    # Обнаруженный дефект: import_state() восстанавливал снимок задачи через
    # TrackedPosition.from_dict(), но НЕ проверял согласованность внешней
    # записи (rec["trade_id"]/rec["figi"]) и самого снимка. В
    # process_closing() внешний rec["trade_id"] используется для проверки
    # завершения задачи, а _recover_late_csv_metadata() — task_pos.trade_id
    # из снимка. При несовпадении идентификаторов задача могла обновить одну
    # строку CSV (по снимку), а завершиться по состоянию другой (по rec).
    #
    # Протокол противоречия (fail-closed): задача НЕ опрашивается у брокера,
    # НЕ изменяет CSV, НЕ затрагивает другие позиции, НЕ удаляется как
    # «успешно завершённая» — она ОСТАЁТСЯ в очереди с маркером "conflict"
    # (причина конфликта персистентна в state.json для аудита) и
    # диагностическим событием.
    #
    # Дубликаты trade_id при импорте:
    #   * ПОЛНЫЕ дубликаты (та же версия, trade_id, figi, ticker, reason и
    #     побайтово тот же снимок) — дедуп до одной записи (детерминированно,
    #     первая; информация не теряется — записи идентичны);
    #   * КОНФЛИКТУЮЩИЕ дубликаты (разные снимки или разные close-ID при
    #     одном trade_id) — ни одна НЕ выбирается произвольно: ОБЕ остаются
    #     с маркером "conflict": duplicate_trade_id_conflicting, никаких
    #     опросов и обновлений CSV.
    # =================================================================

    @staticmethod
    def _recovery_canonical_body(rec) -> str:
        """Каноническая форма записи задачи для сравнения дубликатов
        (без летучего маркера "conflict" и производных метаданных
        "cursor_validation" — оба значения выводимы из снимка задачи);
        детерминированный JSON."""
        return json.dumps(
            {k: v for k, v in rec.items()
             if k not in ("conflict", "cursor_validation")},
            ensure_ascii=False, sort_keys=True, default=str)

    @staticmethod
    def _cursor_identity_state(cursor) -> str:
        """v2.3.10-stage1 (B2 V7, Defect A): СТРОГАЯ трихотомия cursor'а по
        маркеру identity_version — состояния НЕ смешиваются:
          "legacy"  — ключа "identity_version" НЕТ (старые state.json):
                      применяется отдельная legacy-политика — проверка всех
                      ДОСТУПНЫХ идентификаторов, неполнота НЕ выдаётся за
                      полную (cursor_validation="legacy_limited");
          "new"     — маркер присутствует и РАВЕН поддерживаемой версии
                      CURSOR_IDENTITY_VERSION (число и строковое
                      представление эквивалентны — JSON-окружение
                      state.json): строгая проверка обязательных полей
                      (trade_id, FIGI, side, order_id==ключу);
          "invalid" — маркер ПРИСУТСТВУЕТ, но значение пустое (None /
                      пустая строка), нулевое, нечисловое ("abc"),
                      неизвестное или НЕ поддерживаемое (в т.ч. 1, 999):
                      такой cursor НЕ считается legacy и НЕ ослабляет
                      проверку идентичности — fail-closed
                      (cursor_invalid_identity_version); автоматическое
                      повышение версии и молчаливое преобразование формата
                      исключены.
        Отсутствие ключа, None, пустая строка, ноль, нечисловая строка и
        неизвестная числовая версия — РАЗНЫЕ значения маркера; только
        ОТСУТСТВИЕ ключа означает legacy."""
        cursor_dict = cursor if isinstance(cursor, dict) else {}
        if "identity_version" not in cursor_dict:
            return "legacy"
        ver = cursor_dict.get("identity_version")
        try:
            if int(str(ver).strip()) == int(
                    ExecutionMonitor.CURSOR_IDENTITY_VERSION):
                return "new"
        except (TypeError, ValueError):
            pass
        return "invalid"

    @staticmethod
    def _cursor_is_new_format(cursor) -> bool:
        """v2.3.9-stage1 (B2 V6, Defect B); v2.3.10-stage1 (B2 V7, Defect A):
        True — ТОЛЬКО cursor НОВОГО формата (маркер identity_version равен
        поддерживаемой CURSOR_IDENTITY_VERSION, состояние "new").
        ВАЖНО: False НЕ означает «legacy» — False возвращается и для
        LEGACY (ключа нет), и для INVALID/UNKNOWN (маркер пуст,
        некорректен или не поддерживается); различать состояния следует
        через _cursor_identity_state() (см. _cursor_identity_conflict_
        checked / validate_recovery_identity)."""
        return (ExecutionMonitor._cursor_identity_state(cursor) == "new")

    @staticmethod
    def _cursor_identity_conflict(pos, oid, cursor, snap_tid, snap_figi,
                                  strict_new_format: bool) -> Optional[str]:
        """v2.3.9-stage1 (B2 V6, Defect B): проверка ОДНОГО per-order
        cursor'а close-заявки на идентичность снимку сделки.

        strict_new_format=True (НОВЫЙ формат, маркер identity_version):
        обязательные идентификаторы cursor'а — trade_id, FIGI, side и
        идентификатор собственной заявки (order_id, равный ключу
        close_orders — связь с соответствующей close-заявкой). Пустое или
        отсутствующее обязательное поле -> конфликт cursor_missing_*
        (fail-closed). Никакого молчаливого пропуска пустых обязательных
        полей нового формата.

        strict_new_format=False (LEGACY cursor, старые state.json):
        проверяются ВСЕ реально доступные (непустые) идентификаторы;
        НЕПОЛНОТА проверки НЕ считается конфликтом (обратная
        совместимость), но и НЕ выдаётся за полную проверку — режим
        проверки фиксируется cursor_validation_mode().

        Противоречие ДОСТУПНОГО идентификатора снимку — конфликт в ОБОИХ
        форматах (cursor_trade_id_mismatch / cursor_figi_mismatch /
        cursor_side_mismatch / cursor_order_id_mismatch), fail-closed.
        Клиентский UUID (close_order_request_id), биржевой ID
        (close_order_id) и trade_id — РАЗНЫЕ идентификаторы: order_id
        cursor'а обязан совпадать с ключом (собственной close-заявкой),
        trade_id/figi/side — со снимком; ни один не подменяет другой."""
        close_side = "SELL" if pos.direction == "BUY" else "BUY"
        cur_tid = str(cursor.get("trade_id") or "").strip()
        cur_figi = str(cursor.get("figi") or "").strip()
        cur_side = str(cursor.get("side") or "").strip()
        cur_oid = str(cursor.get("order_id") or "").strip()
        # --- обязательные идентификаторы НОВОГО формата ---
        if strict_new_format:
            if not cur_tid:
                return "cursor_missing_trade_id"
            if not cur_figi:
                return "cursor_missing_figi"
            if not cur_side:
                return "cursor_missing_side"
            if not cur_oid:
                return "cursor_missing_order_id"
        # --- противоречия ДОСТУПНЫХ идентификаторов (оба формата) ---
        if cur_tid and cur_tid != snap_tid:
            return "cursor_trade_id_mismatch"
        if cur_figi and cur_figi != snap_figi:
            return "cursor_figi_mismatch"
        if cur_side and cur_side != close_side:
            return "cursor_side_mismatch"
        if cur_oid and cur_oid != str(oid):
            return "cursor_order_id_mismatch"
        return None

    @staticmethod
    def cursor_validation_mode(rec) -> str:
        """v2.3.9-stage1 (B2 V6, Defect B); v2.3.10-stage1 (B2 V7, Defect A):
        режим проверки идентичности per-order cursor'а recovery-задачи:
          "full"            — НОВЫЙ формат cursor'а (identity_version равен
                              поддерживаемой версии), проверены все
                              обязательные идентификаторы;
          "legacy_limited"  — LEGACY cursor (ключа identity_version НЕТ):
                              проверены только реально доступные
                              идентификаторы; неполная проверка НЕ выдаётся
                              за полную;
          "invalid_version" — v2.3.10-stage1 (V7): маркер версии
                              ПРИСУТСТВУЕТ, но пуст/некорректен/не
                              поддерживается (None, "", 0, "abc", 1, 999):
                              fail-closed, НЕ является legacy;
          "none"            — cursor отсутствует (no-cursor recovery-путь,
                              legacy-снимок) или снимок невосстановим.
        Значение сохраняется в задаче (cursor_validation, персистентен в
        state.json) — аудит видит, какой именно режим проверки применён;
        некорректная версия не выдаётся ни за полную, ни за legacy."""
        if not isinstance(rec, dict):
            return "none"
        try:
            pos = TrackedPosition.from_dict(rec.get("position") or {})
        except Exception:
            return "none"
        req_id = getattr(pos, "close_order_request_id", None)
        exch_id = pos.close_order_id
        oid = str(req_id or exch_id or "").strip()
        if not oid:
            return "none"
        cursor = (getattr(pos, "close_orders", {}) or {}).get(oid)
        if not isinstance(cursor, dict):
            return "none"
        cursor_state = ExecutionMonitor._cursor_identity_state(cursor)
        if cursor_state == "new":
            return "full"
        if cursor_state == "legacy":
            return "legacy_limited"
        # v2.3.10-stage1 (B2 V7, Defect A): некорректная/неизвестная версия
        # — отдельный режим (НЕ full, НЕ legacy_limited).
        return "invalid_version"

    @staticmethod
    def _cursor_identity_conflict_checked(pos, oid, cursor, snap_tid,
                                          snap_figi) -> Optional[str]:
        """v2.3.10-stage1 (B2 V7, Defect A): ЕДИНАЯ точка проверки одного
        per-order cursor'а по ТРЁМ состояниям маркера identity_version.

        Порядок проверок (ранний выход на первом конфликте):
          1) state == "invalid" -> "cursor_invalid_identity_version"
             (fail-closed ДО остальных проверок: пустой, нулевой,
             нечисловой или неизвестный маркер версии НЕ превращает
             cursor в legacy и НЕ ослабляет проверку идентичности;
             автоматического повышения версии и молчаливого
             преобразования формата нет);
          2) state == "new"    -> строгая проверка обязательных полей
             (strict_new_format=True): пустое обязательное поле —
             cursor_missing_*, противоречие — cursor_*_mismatch;
          3) state == "legacy" -> проверка всех ДОСТУПНЫХ идентификаторов
             (strict_new_format=False); неполнота НЕ конфликт.
        """
        state = ExecutionMonitor._cursor_identity_state(cursor)
        if state == "invalid":
            return "cursor_invalid_identity_version"
        return ExecutionMonitor._cursor_identity_conflict(
            pos, oid, cursor, snap_tid, snap_figi, (state == "new"))

    @staticmethod
    def validate_recovery_identity(rec) -> Optional[str]:
        """v2.3.8-stage1 (B2 V5, Defect B); v2.3.9-stage1 (B2 V6, Defect B);
        v2.3.10-stage1 (B2 V7, Defect A): проверка согласованности внешней
        записи recovery-задачи и её снимка позиции.

        Возвращает None (задача идентично согласована) или ПРИЧИНУ конфликта
        (строка). Проверяются:
          * rec.trade_id == snapshot.trade_id;
          * rec.figi == snapshot.figi;
          * наличие стабильного trade_id и FIGI;
          * наличие СВОЕЙ close-заявки (close_order_request_id /
            close_order_id — клиентский UUID или биржевой ID);
          * v2.3.9-stage1 (V6): СТРОГАЯ проверка per-order cursor'а этой
            заявки:
            - НОВЫЙ формат (identity_version): обязательны trade_id, FIGI,
              side, order_id (== ключу close_orders); пустое обязательное
              поле — конфликт cursor_missing_*, противоречие —
              cursor_*_mismatch (fail-closed);
            - LEGACY (без маркера версии): проверяются все ДОСТУПНЫЕ
              идентификаторы, противоречие — fail-closed, неполнота —
              НЕ конфликт, но и НЕ полная проверка
              (cursor_validation="legacy_limited");
            - v2.3.10-stage1 (V7): ИНВАЛИДНАЯ/НЕИЗВЕСТНАЯ версия маркера
              (присутствует, но пуст/некорректен/не поддерживается):
              конфликт cursor_invalid_identity_version (fail-closed ДО
              остальных проверок; такой cursor НЕ считается legacy);
          * существующий cursor по ВТОРОЙ сохранённой ссылке той же
            close-заявки (клиентский UUID / биржевой ID) также не может
            противоречить снимку — ни один идентификатор не подменяет
            другой (v2.3.10-stage1: та же трёхсостояняя проверка через
            _cursor_identity_conflict_checked).
        Отсутствующий cursor (легаси-снимок) НЕ конфликт: опрос невозможен,
        но и подмены идентичности нет — штатный no_cursor-путь recovery
        (cursor_validation="none")."""
        if not isinstance(rec, dict):
            return "not_dict"
        snap = rec.get("position")
        if not isinstance(snap, dict):
            return "no_snapshot"
        try:
            pos = TrackedPosition.from_dict(snap)
        except Exception:
            return "snapshot_unrestorable"
        rec_tid = str(rec.get("trade_id") or "").strip()
        snap_tid = str(getattr(pos, "trade_id", "") or "").strip()
        if not snap_tid:
            return "no_trade_id"
        if rec_tid != snap_tid:
            return "trade_id_mismatch"
        snap_figi = str(getattr(pos, "figi", "") or "").strip()
        if not snap_figi:
            return "no_figi"
        rec_figi = str(rec.get("figi") or "").strip()
        if rec_figi and rec_figi != snap_figi:
            return "figi_mismatch"
        req_id = getattr(pos, "close_order_request_id", None)
        exch_id = pos.close_order_id
        oid = str(req_id or exch_id or "").strip()
        if not oid:
            return "no_close_order_ref"
        close_orders = (getattr(pos, "close_orders", {}) or {})
        if not isinstance(close_orders, dict):
            close_orders = {}
        cursor = close_orders.get(oid)
        if cursor is not None:
            conflict = ExecutionMonitor._cursor_identity_conflict_checked(
                pos, oid, cursor, snap_tid, snap_figi)
            if conflict is not None:
                return conflict
        # v2.3.9-stage1 (B2 V6): ВТОРАЯ сохранённая ссылка той же
        # close-заявки (клиентский UUID и биржевой ID — РАЗНЫЕ типы
        # идентификаторов). Cursor по ней не обязан существовать, но
        # существующий не может противоречить снимку: ни один
        # идентификатор не подменяет другой только потому, что все они
        # строки.
        other_refs = {str(req_id or "").strip(),
                      str(exch_id or "").strip()} - {oid, ""}
        for ref in sorted(other_refs):
            alt_cursor = close_orders.get(ref)
            if isinstance(alt_cursor, dict):
                conflict = ExecutionMonitor._cursor_identity_conflict_checked(
                    pos, ref, alt_cursor, snap_tid, snap_figi)
                if conflict is not None:
                    return conflict
        return None

    def _import_pending_recoveries(self, raw_pending) -> List[dict]:
        """v2.3.8-stage1 (B2 V5, Defect B): импорт незавершённых recovery-задач
        с валидацией идентичности и обработкой дубликатов.

        Структурно нечитаемые записи (не dict) сохранять нечего — они
        отбрасываются с журналом (fail-closed по записи, без падения
        процесса). Все ОСТАЛЬНЫЕ записи сохраняются; запись с нарушенной
        идентичностью получает маркер "conflict" с причиной (персистентен
        в state.json, экспортируется/импортируется обратно) — задача остаётся в очереди,
        но recovery-циклом НЕ обрабатывается (fail-closed протокол выше).
        Ревалидация при каждом импорте идемпотентна: исправленная запись
        снова становится пригодной (маркер перезаписывается актуальным
        результатом проверки)."""
        if not isinstance(raw_pending, list):
            logging.error(
                "[execution] import_state: pending_csv_recoveries не list — "
                "восстановление задач пропущено (обратная совместимость)")
            return []
        staged: List[dict] = []
        for rec in raw_pending:
            if not isinstance(rec, dict):
                logging.error(
                    "[execution] import_state: запись "
                    "pending_csv_recoveries не dict — отброшена "
                    "(сохранять нечего)")
                continue
            staged.append(dict(rec))
        # --- дубликаты trade_id ---
        grouped: Dict[str, List[dict]] = {}
        for rec in staged:
            tid = str(rec.get("trade_id")
                      or (rec.get("position") or {}).get("trade_id")
                      or "")
            if tid:
                grouped.setdefault(tid, []).append(rec)
        identical_dup_ids = set()
        conflicting_dup_ids = set()
        for tid, recs in grouped.items():
            if len(recs) < 2:
                continue
            bodies = {self._recovery_canonical_body(r) for r in recs}
            if len(bodies) == 1:
                identical_dup_ids.add(tid)  # полные дубликаты — дедуп
            else:
                conflicting_dup_ids.add(tid)  # разные снимки/close-ID
        pending: List[dict] = []
        seen_identical: set = set()
        for rec in staged:
            tid = str(rec.get("trade_id")
                      or (rec.get("position") or {}).get("trade_id")
                      or "")
            if tid in identical_dup_ids:
                if tid in seen_identical:
                    logging.warning(
                        "[execution] import_state: полная копия recovery-задачи "
                        f"trade_id={tid} пропущена (дедуп, записи идентичны)")
                    continue
                seen_identical.add(tid)
            conflict = self.validate_recovery_identity(rec)
            if conflict is None and tid in conflicting_dup_ids:
                conflict = "duplicate_trade_id_conflicting"
            snap = rec.get("position")
            display_tid = str(
                rec.get("trade_id")
                or (snap.get("trade_id") if isinstance(snap, dict) else "")
                or "?")
            if conflict is not None:
                logging.error(
                    "[execution] import_state: recovery-задача "
                    f"trade_id={display_tid} — конфликт идентичности "
                    f"({conflict}) — оставлена с маркером, брокер не "
                    "опрашивается, CSV не изменяется (fail-closed)")
            # v2.3.9-stage1 (B2 V6, Defect B): режим проверки идентичности
            # cursor'а этой задачи — производное метаданное снимка;
            # персистентно (state.json). Неполная (legacy) проверка НЕ
            # выдаётся за полную: в записи остаётся явный
            # cursor_validation="legacy_limited". Ревалидация при импорте
            # идемпотентна (значение выводится из снимка заново).
            cursor_validation = self.cursor_validation_mode(rec)
            pending.append({
                "version": rec.get("version", 1),
                "trade_id": str(rec.get("trade_id")
                                or (snap.get("trade_id") if isinstance(snap, dict) else "")
                                or ""),
                "figi": rec.get("figi") or (snap.get("figi") if isinstance(snap, dict) else "") or "",
                "ticker": rec.get("ticker") or (snap.get("ticker") if isinstance(snap, dict) else "") or "",
                "reason": rec.get("reason", ""),
                "position": snap if isinstance(snap, dict) else snap,
                "cursor_validation": cursor_validation,
                # v2.3.8-stage1: маркер конфликта персистентен (аудит);
                # None для согласованных задач — ключ не добавляется.
                **({"conflict": conflict} if conflict is not None else {}),
            })
            if (conflict is None and cursor_validation == "legacy_limited"):
                logging.info(
                    "[execution] import_state: recovery-задача "
                    f"trade_id={display_tid} — LEGACY cursor (без маркера "
                    "identity_version): проверены только доступные "
                    "идентификаторы, неполная проверка НЕ является полной "
                    "(cursor_validation=legacy_limited, обратная "
                    "совместимость)")
        return pending

    def import_state(self, data):
        if not isinstance(data, dict):
            logging.error("[execution] import_state: data is not dict")
            return
        # Обратная совместимость: старый state.json без ключа -> пустой список.
        raw_closed = data.get("closed_entry_order_ids", [])
        if isinstance(raw_closed, list):
            # Дополнительный этап: полный импорт без обрезки — все признаки
            # закрытых сделок должны переживать перезапуск.
            self.closed_entry_order_ids = [str(x) for x in raw_closed if x]
        else:
            self.closed_entry_order_ids = []
        restored = {}
        positions = data.get("positions", {})
        if not isinstance(positions, dict):
            logging.error("[execution] import_state: positions is not dict")
            return
        for figi, raw in positions.items():
            try:
                pos = TrackedPosition.from_dict(raw)
                if pos.figi != figi:
                    raise ValueError("FIGI key mismatch")
                # Validate persisted close journal; malformed journal fails closed.
                if not isinstance(pos.close_orders, dict) or not isinstance(pos.close_applications, list):
                    raise ValueError("invalid close journal")
                restored[figi] = pos
            except Exception as exc:
                logging.error(f"[execution] import_state {figi}: {type(exc).__name__}: {exc}")
        self.positions = restored
        self.monitoring_error = bool(data.get("monitoring_error", False))
        # v2.3.7-stage1 (B2 V4): восстановление незавершённых recovery-задач.
        # Обратная совместимость: старый state.json без ключа -> пустой
        # список. v2.3.8-stage1 (B2 V5, Defect B): валидация идентичности
        # каждой задачи (внешняя запись <-> снимок <-> per-order cursor),
        # обработка дубликатов trade_id; противоречивая задача ОСТАЁТСЯ
        # с маркером "conflict" и не может обновить CSV (fail-closed,
        # см. шапку v2.3.8-stage1).
        pending = self._import_pending_recoveries(
            data.get("pending_csv_recoveries", []))
        self.pending_csv_recoveries = pending
        if pending:
            logging.warning(
                f"[execution] import_state: восстановлено незавершённых "
                f"recovery-задач CSV: {len(pending)}")
